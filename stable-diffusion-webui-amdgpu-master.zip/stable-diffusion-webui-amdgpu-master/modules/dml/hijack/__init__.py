import modules.dml.hijack.torch
import modules.dml.hijack.transformers # noqa: F401
